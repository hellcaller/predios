package microservicio.sda.predios.estudiosyconceptos.services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import microservicio.proyecto.commons.services.CommonServiceImpl;
import microservicio.sda.predios.estudiosyconceptos.models.entity.EstudiosyConceptos;
import microservicio.sda.predios.estudiosyconceptos.models.repository.estudioyconceptosRepository;


@Service
public class estudiosyconceptosServicesImpl extends CommonServiceImpl<EstudiosyConceptos, estudioyconceptosRepository> implements estudiosyconceptosService{

	@Override
	@Transactional(readOnly = true)
	public Iterable<EstudiosyConceptos> findAll() {
		return repository.findAllByOrderByIdAsc();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<EstudiosyConceptos> findAll(Pageable pageable) {
		return repository.findAllByOrderByIdAsc(pageable);
	}

	@Override
	public Iterable<EstudiosyConceptos> findAllById(Iterable<Long> ids) {
		
		return repository.findAllById(ids);
	}

}
