package microservicio.sda.predios.estudiosyconceptos.services;

import microservicio.proyecto.commons.services.CommonService;
import microservicio.sda.predios.estudiosyconceptos.models.entity.EstudiosyConceptos;


public interface estudiosyconceptosService extends CommonService<EstudiosyConceptos> {
	public Iterable<EstudiosyConceptos> findAllById(Iterable<Long> ids);
}
