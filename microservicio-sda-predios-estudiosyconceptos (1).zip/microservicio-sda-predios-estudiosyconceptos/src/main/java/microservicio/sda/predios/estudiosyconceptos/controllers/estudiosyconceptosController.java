package microservicio.sda.predios.estudiosyconceptos.controllers;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



import microservicio.proyecto.commons.controller.CommonController;
import microservicio.sda.predios.estudiosyconceptos.models.entity.EstudiosyConceptos;
import microservicio.sda.predios.estudiosyconceptos.services.estudiosyconceptosService;

@CrossOrigin("*")
@RestController
public class estudiosyconceptosController extends CommonController<EstudiosyConceptos, estudiosyconceptosService> {

	
	@PutMapping("/{id}")
	public ResponseEntity<?> editar(@RequestBody EstudiosyConceptos informacionestycon, @PathVariable Long id) {
		Optional<EstudiosyConceptos> optional = service.findById(id);
		if (optional.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		EstudiosyConceptos informacionestyconDB = optional.get();
		informacionestyconDB.setEstudiotitulos(informacionestycon.getEstudiotitulos());
		informacionestyconDB.setElaboradopor(informacionestycon.getElaboradopor());
		informacionestyconDB.setFecharealizacion(informacionestycon.getFecharealizacion());
		informacionestyconDB.setLimitacion(informacionestycon.getLimitacion());
		informacionestyconDB.setDescripcion(informacionestycon.getDescripcion());
		informacionestyconDB.setVersiondoc(informacionestycon.getVersiondoc());
		informacionestyconDB.setAnexos(informacionestycon.getAnexos());		
		return ResponseEntity.status(HttpStatus.CREATED).body(service.save(informacionestyconDB));
	}
	
}
