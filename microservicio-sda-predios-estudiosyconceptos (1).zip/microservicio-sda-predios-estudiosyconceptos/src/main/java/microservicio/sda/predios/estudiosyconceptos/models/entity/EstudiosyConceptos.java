package microservicio.sda.predios.estudiosyconceptos.models.entity;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.microservicio.sda.predios.app.informaciongeneral.models.entity.InformacionGeneral;

@Entity
@Table(name = "estudiosyconceptos")
public class EstudiosyConceptos {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String estudiotitulos;
	private String elaboradopor;
	private Timestamp fecharealizacion;
	private String limitacion;
	private String descripcion;
	private String versiondoc;
	private String anexos;
	
	@OneToMany(fetch = FetchType.LAZY)
	private List<InformacionGeneral> informacion_general;
	
	public EstudiosyConceptos() {
		this.informacion_general = new ArrayList<>();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEstudiotitulos() {
		return estudiotitulos;
	}

	public void setEstudiotitulos(String estudiotitulos) {
		this.estudiotitulos = estudiotitulos;
	}

	public String getElaboradopor() {
		return elaboradopor;
	}

	public void setElaboradopor(String elaboradopor) {
		this.elaboradopor = elaboradopor;
	}

	public Timestamp getFecharealizacion() {
		return fecharealizacion;
	}

	public void setFecharealizacion(Timestamp fecharealizacion) {
		this.fecharealizacion = fecharealizacion;
	}

	public String getLimitacion() {
		return limitacion;
	}

	public void setLimitacion(String limitacion) {
		this.limitacion = limitacion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getVersiondoc() {
		return versiondoc;
	}

	public void setVersiondoc(String versiondoc) {
		this.versiondoc = versiondoc;
	}

	public String getAnexos() {
		return anexos;
	}

	public void setAnexos(String anexos) {
		this.anexos = anexos;
	}
	
	
	
	
	public List<InformacionGeneral> getInformacion_general() {
		return informacion_general;
	}

	public void setInformacion_fiscal(List<InformacionGeneral> informacion_general) {
		this.informacion_general = informacion_general;
	}

	public void addInformacion_fiscal(InformacionGeneral informacion_general) {
		this.informacion_general.add(informacion_general);
	}

	public void removeInformacion_fiscal(InformacionGeneral informacion_general) {
		this.informacion_general.remove(informacion_general);
	}

	@Override
	public String toString() {
		return "EstudiosyConceptos [id=" + id + ", estudiotitulos=" + estudiotitulos + ", elaboradopor=" + elaboradopor
				+ ", fecharealizacion=" + fecharealizacion + ", limitacion=" + limitacion + ", descripcion="
				+ descripcion + ", versiondoc=" + versiondoc + ", anexos=" + anexos + "]";
	}
	
	
	
	

}
