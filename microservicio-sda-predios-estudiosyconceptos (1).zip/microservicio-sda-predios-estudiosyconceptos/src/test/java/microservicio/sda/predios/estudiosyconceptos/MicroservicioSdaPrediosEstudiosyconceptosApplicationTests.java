package microservicio.sda.predios.estudiosyconceptos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioSdaPrediosEstudiosyconceptosApplicationTests {

	@Test
	void contextLoads() {
	}

}
