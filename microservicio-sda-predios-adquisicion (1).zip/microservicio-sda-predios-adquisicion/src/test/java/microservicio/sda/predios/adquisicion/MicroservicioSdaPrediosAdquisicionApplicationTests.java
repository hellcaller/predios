package microservicio.sda.predios.adquisicion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioSdaPrediosAdquisicionApplicationTests {

	@Test
	void contextLoads() {
	}

}
