package microservicio.sda.predios.tecnica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioSdaPrediosTecnicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
