package microservicio.sda.predios.app.tecnica.repository;



import microservicio.proyecto.commons.services.CommonService;
import microservicio.sda.predios.app.tecnica.models.entity.InformacionTecnica;

public interface informacionTecnicaService  extends CommonService<InformacionTecnica> {
	public Iterable<InformacionTecnica> findAllById(Iterable<Long> ids);
}
