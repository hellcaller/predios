package microservicio.sda.predios.app.tecnica.repository;



import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import microservicio.proyecto.commons.services.CommonServiceImpl;
import microservicio.sda.predios.app.tecnica.models.entity.InformacionTecnica;
import microservicio.sda.predios.app.tecnica.models.repository.TecnicaRepository;

@Service
public class InformacionTecnicaServiceImpl  extends CommonServiceImpl<InformacionTecnica, TecnicaRepository> implements informacionTecnicaService {

	@Override
	@Transactional(readOnly = true)
	public Iterable<InformacionTecnica> findAll() {
		return repository.findAllByOrderByIdAsc();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<InformacionTecnica> findAll(Pageable pageable) {
		return repository.findAllByOrderByIdAsc(pageable);
	}

	@Override
	public Iterable<InformacionTecnica> findAllById(Iterable<Long> ids) {
		return repository.findAllById(ids);
	}
}
