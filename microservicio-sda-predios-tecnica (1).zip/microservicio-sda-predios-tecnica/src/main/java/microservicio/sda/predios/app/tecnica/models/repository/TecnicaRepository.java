package microservicio.sda.predios.app.tecnica.models.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;



import microservicio.sda.predios.app.tecnica.models.entity.InformacionTecnica;



public interface TecnicaRepository extends PagingAndSortingRepository<InformacionTecnica, Long> {

	public Iterable<InformacionTecnica> findAllByOrderByIdAsc();
	
	public Page<InformacionTecnica> findAllByOrderByIdAsc(Pageable pageable);
}
